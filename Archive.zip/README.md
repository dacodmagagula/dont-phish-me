## Don't Phish Me


<p>An Open Source Google Chrome Extension that protects you from phishing attacks by letting you specify what usernames you use to login to services, and whitelisting them for specific domains. If you use the username on a domain that you have not whitelisted 'Don't Phish Me' alerts you.</p>

<img src="https://s3-eu-west-1.amazonaws.com/dacod.co.za/images/dontphishme.png" alt="dontphishme.png"/>

## Privacy

<p>Don't Phish Me saves all your data locally on your browser. You can also download the code and install it locally.</p>


## License

You can use this code however you like (see LICENSE).